# advanced-data-engineering-test-data-example
This simple repo stores a notebook used to create a test dataset for ci/cd.
